---
name: Green Car Airport
colors:
  surface: '#f9f9ff'
  surface-dim: '#d3daea'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f0f3ff'
  surface-container: '#e7eefe'
  surface-container-high: '#e2e8f8'
  surface-container-highest: '#dce2f3'
  on-surface: '#151c27'
  on-surface-variant: '#3e4a40'
  inverse-surface: '#2a313d'
  inverse-on-surface: '#ebf1ff'
  outline: '#6e7a6f'
  outline-variant: '#becabd'
  surface-tint: '#006d38'
  primary: '#006a36'
  on-primary: '#ffffff'
  primary-container: '#138648'
  on-primary-container: '#f6fff4'
  inverse-primary: '#75db94'
  secondary: '#506071'
  on-secondary: '#ffffff'
  secondary-container: '#d4e4f9'
  on-secondary-container: '#566677'
  tertiary: '#735c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#cca830'
  on-tertiary-container: '#4f3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#91f8ae'
  primary-fixed-dim: '#75db94'
  on-primary-fixed: '#00210d'
  on-primary-fixed-variant: '#005229'
  secondary-fixed: '#d4e4f9'
  secondary-fixed-dim: '#b8c8dc'
  on-secondary-fixed: '#0d1d2c'
  on-secondary-fixed-variant: '#394859'
  tertiary-fixed: '#ffe088'
  tertiary-fixed-dim: '#e9c349'
  on-tertiary-fixed: '#241a00'
  on-tertiary-fixed-variant: '#574500'
  background: '#f9f9ff'
  on-background: '#151c27'
  surface-variant: '#dce2f3'
  light-green: '#E8F5EE'
  warm-white: '#F8FAF9'
  border-gray: '#E5E7EB'
  alert-orange: '#F59E0B'
  success-green: '#10B981'
  danger-red: '#EF4444'
typography:
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  h2:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  cta-button:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 1rem
  gutter-grid: 1rem
  touch-target-min: 48px
  stack-sm: 0.5rem
  stack-md: 1rem
  stack-lg: 1.5rem
---

# Green Car Airport — UI Design Specification for Mockup

> **Tool:** Google Stitch  
> **Goal:** Generate high-fidelity mobile mockups for customer demo  
> **Platform:** Progressive Web App (PWA), mobile-first  
> **Target devices:** iPhone 14 Pro / Android (390×844px viewport)

---

## 1. Brand & Visual Identity

### Brand Personality
Professional, trustworthy, eco-friendly, efficient. Inspired by premium ride-hailing apps but tailored for Vietnamese airport transfer context.

### Color Palette

| Token | Hex | Usage |
|---|---|---|
| Primary Green | `#1B8A4C` | CTA buttons, active states, brand accents |
| Light Green | `#E8F5EE` | Card backgrounds, success states |
| Dark Navy | `#0F1F2E` | Headers, primary text |
| Warm White | `#F8FAF9` | App background |
| Neutral Gray | `#6B7280` | Secondary text, labels |
| Border Gray | `#E5E7EB` | Dividers, input borders |
| Alert Orange | `#F59E0B` | Pending status badges |
| Success Green | `#10B981` | Completed status badges |
| Danger Red | `#EF4444` | Cancel, block, error states |
| Gold | `#D4AF37` | Point/credits display |

### Typography
- **Font:** Inter (Google Fonts)
- **H1:** 24px, Bold, Dark Navy
- **H2:** 18px, SemiBold, Dark Navy  
- **Body:** 14px, Regular, Dark Navy
- **Caption:** 12px, Regular, Neutral Gray
- **CTA Button Text:** 16px, SemiBold, White

### Design Principles
- Rounded corners: 12px (cards), 8px (inputs), 999px (pills/badges)
- Card shadow: `0 2px 8px rgba(0,0,0,0.08)`
- Bottom navigation bar (5 tabs max)
- Large touch targets: minimum 48×48px
- Status bar: dark content on light background
